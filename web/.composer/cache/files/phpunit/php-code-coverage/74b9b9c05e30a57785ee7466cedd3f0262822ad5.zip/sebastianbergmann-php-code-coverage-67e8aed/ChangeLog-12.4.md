# ChangeLog

All notable changes are documented in this file using the [Keep a CHANGELOG](http://keepachangelog.com/) principles.

## [12.4.0] - 2025-09-24

### Added

* [#1095](https://github.com/sebastianbergmann/php-code-coverage/pull/1095): Support for light/dark mode in HTML report

[12.4.0]: https://github.com/sebastianbergmann/php-code-coverage/compare/12.3.8...main
